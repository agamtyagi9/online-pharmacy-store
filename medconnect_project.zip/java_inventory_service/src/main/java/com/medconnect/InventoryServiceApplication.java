package com.medconnect;

public class InventoryServiceApplication {
  public static void main(String[] args) {
    System.out.println("Inventory Service Running");
  }
}
